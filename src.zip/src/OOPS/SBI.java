package OOPS;

public class SBI implements Bank{

	public int homeLoan() {
		return 7;
		
	}
	

}
