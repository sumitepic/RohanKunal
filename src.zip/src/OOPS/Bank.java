package OOPS;

public interface Bank {

	public int homeLoan();
}
