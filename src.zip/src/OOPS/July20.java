package OOPS;

public class July20 {
	
	public void f456(){
		
	}
	
	public static void main(String[] args) {
		System.out.println(interfaceDemo.a);
	}

}
