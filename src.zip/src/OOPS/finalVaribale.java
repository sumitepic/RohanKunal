package OOPS;

public class finalVaribale {

	final int a =8;
	
	public void f2(){
		System.out.println(a);
	}
	
	public static void main(String[] args) {
		
	}
	
	
}
