package OOPS;

public class Parent {

	public void f1(){
		System.out.println("Parent");
	}
	
	public void f1(int a){
		System.out.println("Parent"+a);
	}
	

	public void f1(long a){
		System.out.println("Parent"+a);
	}
}
