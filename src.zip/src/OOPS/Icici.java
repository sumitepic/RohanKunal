package OOPS;

public class Icici implements Bank{

	public int homeLoan() {
		return 8;
		
	}

}
