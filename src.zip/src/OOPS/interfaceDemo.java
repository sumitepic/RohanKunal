package OOPS;

public interface interfaceDemo {
	
	int a =19;
	
	public abstract void f1();
	public void f2();

}
