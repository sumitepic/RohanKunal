
public class first {
	
	static int a =90;
	
	public void f1(){
		System.out.println(a);
	}
	
	public static void main(String[] args) {
		//className variableName = new className();
		first sumit= new first(); //object
		sumit.f1();
		
		int a =13;
		System.out.println(a);
	}

	
	
}

