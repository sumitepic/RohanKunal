package OOPS1;

public interface firstInterface {
	
	public void g1();

}
