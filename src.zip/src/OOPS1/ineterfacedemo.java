package OOPS1;

public interface ineterfacedemo extends firstInterface{

	public void f3();
}
