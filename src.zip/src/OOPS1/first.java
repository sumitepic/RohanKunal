package OOPS1;

public abstract class first implements ineterfacedemo{
	int s=90;

	public abstract void f2();
	
	public first(){
		
	}
	
	public void f1(){
		System.out.println("F1");
	}
	
	
}
