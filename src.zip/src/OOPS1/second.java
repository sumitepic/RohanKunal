package OOPS1;

public class second extends first {

	@Override
	public void f3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void f2() {
		// TODO Auto-generated method stub
		System.out.println(s);
	}

	@Override
	public void g1() {
		// TODO Auto-generated method stub
		
	}
	
	

}
