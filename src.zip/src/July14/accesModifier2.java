package July14;

public class accesModifier2 extends accesModifier{
	
	public void f1(){
		setA(10);
		System.out.println(getA());
	}
	
	public static void main(String[] args) {
		//f1();
	}
	

}
