package ExceptionHandling;

public class CustomException extends Exception{
	
	public CustomException(){
		System.out.println("Custom exception");
	}
	

}
